
package com.booking.user.service;

import com.booking.user.Model.BookingHistory;
import com.booking.user.repository.BookingHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingHistoryService {
    private final BookingHistoryRepository bookingHistoryRepository;

    @Autowired
    public BookingHistoryService(BookingHistoryRepository bookingHistoryRepository) {
        this.bookingHistoryRepository = bookingHistoryRepository;
    }

    public BookingHistory saveBookingHistory(BookingHistory bookingHistory) {
        return bookingHistoryRepository.save(bookingHistory);
    }


    public List<BookingHistory> findBookingHistoryByEmail(String email) {
        return bookingHistoryRepository.findByEmail(email);
    }

    public List<BookingHistory> findBookingHistory() {
        return  bookingHistoryRepository.findAll();
    }
}
