package com.booking.user.Model;

import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;

@Entity
@Table(name = "BookingHistory")
@NoArgsConstructor
@Getter
@Setter
@ToString
@AllArgsConstructor
public class BookingHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String name;
    private String email;
    private String hotelName;
    private ArrayList<Room> rooms; // Change type to ArrayList<Room>
    private double totalCost;
}
