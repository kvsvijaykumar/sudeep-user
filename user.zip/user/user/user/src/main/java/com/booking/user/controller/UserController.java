package com.booking.user.controller;

import com.booking.user.Model.Login;
import com.booking.user.Model.User;
import com.booking.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/signup")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {


   @Autowired
   private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;

    }

    @GetMapping("/getAllUsers")
    public List<User> getAllUsers(){
        try{
           return  userService.getAllUsers();
        }catch(Exception ex){
            return new ArrayList<>();
        }
    }


    @PostMapping ("/newUsers")
    public String registerNewUser(@RequestBody User user){
        try{
            return  userService.registerNewUser(user);
        }catch(Exception ex){
            return "Failed to register";
        }
    }
    @PostMapping("/email")
    public User getByEmailAndPassword(@RequestBody Login login) {
        try {
            User data = userService.verify(login);
            System.out.println(data);
            return data;
        } catch(Exception ex) {
            return null;
        }
    }

}
