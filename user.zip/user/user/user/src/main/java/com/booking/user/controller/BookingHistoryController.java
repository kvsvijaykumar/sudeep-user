package com.booking.user.controller;

import com.booking.user.Model.BookingHistory;
import com.booking.user.service.BookingHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/booking-history")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingHistoryController {
    private final BookingHistoryService bookingHistoryService;

    @Autowired
    public BookingHistoryController(BookingHistoryService bookingHistoryService) {
        this.bookingHistoryService = bookingHistoryService;
    }

    @PostMapping("/add")
    public BookingHistory addBookingHistory(@RequestBody BookingHistory bookingHistory) {
        // If rooms is null, initialize it as an empty ArrayList
        if (bookingHistory.getRooms() == null) {
            bookingHistory.setRooms(new ArrayList<>());
        }
        return bookingHistoryService.saveBookingHistory(bookingHistory);
    }

    @GetMapping("/")
    public List<BookingHistory> getBookingHistory() {
        return bookingHistoryService.findBookingHistory();
    }

    @GetMapping("/by-email")
    public List<BookingHistory> getBookingHistoryByEmail(@RequestParam String email) {
        return bookingHistoryService.findBookingHistoryByEmail(email);
    }
}
