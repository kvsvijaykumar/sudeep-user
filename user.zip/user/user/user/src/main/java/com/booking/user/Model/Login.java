package com.booking.user.Model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Login")
@NoArgsConstructor
@Setter
@Getter
@ToString
@AllArgsConstructor
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private  int id;
    private String email;
    private String password;
}
