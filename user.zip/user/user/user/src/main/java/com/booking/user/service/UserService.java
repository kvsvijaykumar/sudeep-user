package com.booking.user.service;

import com.booking.user.Model.Login;
import com.booking.user.Model.User;
import com.booking.user.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
//    @Autowired
    private final UserRepo userRepo;
    @Autowired
    public UserService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public List<User> getAllUsers(){
        return userRepo.findAll();
    }

    public  String registerNewUser(User user){
        try{

            userRepo.save(user);
            return "Succefully Registered the user";
        }catch(Exception ex){
            return "Registration failed";
        }
    }

    public User verify(Login login) {
        try {
            return userRepo.findByEmailAndPassword(login.getEmail(),login.getPassword());
        }catch (Exception ex){
            return  null;
        }
    }
}
